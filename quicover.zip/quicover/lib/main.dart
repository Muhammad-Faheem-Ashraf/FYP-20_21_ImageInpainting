import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:quicover/constant.dart';
import 'package:quicover/fun_gallery.dart';
import 'package:quicover/selection.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: Get.key,
      navigatorObservers: [GetObserver()],
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xFF9BE4FF),
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                gradient: new LinearGradient(
                    colors: [
                  Color(0xFF9BE4FF),
                  Colors.white,
                ],
                    stops: [
                  0.0,
                  1.0
                ],
                    begin: FractionalOffset.bottomCenter,
                    end: FractionalOffset.topCenter,
                    tileMode: TileMode.repeated)),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(
                  top: size.height * 0.1, bottom: size.height * 0.1),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    height: 100,
                    width: size.width * 0.8,
                    child: Row(
                      children: [
                        Container(
                          height: size.width * 0.2,
                          child: Image(
                            image: AssetImage("assets/App Logo.png"),
                          ),
                        ),
                        Container(
                          height: size.width * 0.2,
                          child: Image(
                            image: AssetImage("assets/Name.png"),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Container(
                  //   height: size.height * 0.1,
                  //   width: size.width * 0.8,
                  //   child: Stack(
                  //     children: [
                  //       Container(
                  //         decoration: new BoxDecoration(
                  //             border: Border.all(color: Colors.transparent),
                  //             borderRadius: BorderRadius.circular(30),
                  //             gradient: new LinearGradient(
                  //                 colors: [
                  //                   Colors.grey.shade200,
                  //                   Colors.white,
                  //                 ],
                  //                 stops: [
                  //                   0.0,
                  //                   1.0
                  //                 ],
                  //                 begin: FractionalOffset.bottomCenter,
                  //                 end: FractionalOffset.topCenter,
                  //                 tileMode: TileMode.repeated)),
                  //       ),
                  //       Center(
                  //         child: MaterialButton(
                  //             child: Text(
                  //               "Remove Noise",
                  //               style: TextStyle(
                  //                   fontSize: 30, color: AppColor.secondary),
                  //             ),
                  //             onPressed: () {}),
                  //       ),
                  //     ],
                  //   ),
                  //   decoration: BoxDecoration(
                  //       border: Border.all(color: AppColor.secondary),
                  //       borderRadius: BorderRadius.circular(30)),
                  // ),

                  getButton("Fun Gallery", -1),
                  getButton("Remove Noise", 0),
                  // getButton("Colourize B&W", 1),
                  // getButton("Super Resolution", 2),
                  getButton("Restore Image", 1),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  getButton(String name, int type) {
    var size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () {
        if (type == -1) {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => FunGalleryScreen()));
        } else {
          print("HEREE IN MAIN SCREEEEN IT IS ");
          print(type);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => SelectionScreen(
                        type: type,
                      )));
        }
      },
      child: Container(
        height: size.height * 0.1,
        width: size.width * 0.8,
        child: Stack(
          children: [
            Container(
              decoration: new BoxDecoration(
                  border: Border.all(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(30),
                  gradient: new LinearGradient(
                      colors: [
                        Colors.grey.shade200,
                        Colors.white,
                      ],
                      stops: [
                        0.0,
                        1.0
                      ],
                      begin: FractionalOffset.bottomCenter,
                      end: FractionalOffset.topCenter,
                      tileMode: TileMode.repeated)),
            ),
            Center(
              child: MaterialButton(
                  child: Text(
                    name,
                    style: TextStyle(fontSize: 30, color: AppColor.secondary),
                  ),
                  onPressed: () {
                    if (type == -1) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => FunGalleryScreen()));
                    } else {
                      print("HEREE IN MAIN SCREEEEN IT IS ");
                      print(type);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SelectionScreen(
                                    type: type,
                                  )));
                    }
                  }),
            ),
          ],
        ),
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.secondary),
            borderRadius: BorderRadius.circular(30)),
      ),
    );
  }
}
