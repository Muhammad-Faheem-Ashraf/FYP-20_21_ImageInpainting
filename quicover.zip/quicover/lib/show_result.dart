import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:quicover/constant.dart';
import 'package:quicover/main.dart';
import 'package:quicover/selection.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
// import 'package:path/path.dart';
import 'package:async/async.dart';

class ShowResultScreen extends StatefulWidget {
  ShowResultScreen({Key key, this.image, this.list, this.fileImage})
      : super(key: key) {
    img = image;
  }
  final ImageProvider image;
  final Uint8List list;
  final File fileImage;
  var img;
  var isResult = false;
  @override
  _ShowResultScreenState createState() => _ShowResultScreenState();
}

class _ShowResultScreenState extends State<ShowResultScreen> {
  bool isUploadStart = false;
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xFF9BE4FF),
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                gradient: new LinearGradient(
                    colors: [
                  Color(0xFF9BE4FF),
                  Colors.white,
                ],
                    stops: [
                  0.0,
                  1.0
                ],
                    begin: FractionalOffset.bottomCenter,
                    end: FractionalOffset.topCenter,
                    tileMode: TileMode.repeated)),
          ),
          Center(
            child: Container(
                height: size.height * 0.6,
                width: size.width * 0.9,
                child: widget.image == null
                    ? Text('No image selected.')
                    : Image(image: widget.img)),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 0),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: getButton("BACK", 0),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 0),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: getButton("UPLOAD", 1),
                  ),
                )
              ],
            ),
          ),
          // Padding(
          //   padding: const EdgeInsets.only(bottom: 50),
          //   child: Align(
          //     alignment: Alignment.bottomCenter,
          //     child: getButton("BACK", 0),
          //   ),
          // )
          isUploadStart
              ? Container(
                  color: Colors.black.withOpacity(0.5),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                )
              : Container(),
          isUploadStart
              ? Center(child: CircularProgressIndicator())
              : Container()
        ],
      ),
    );
  }

  getButton(String name, int type) {
    var size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () async {
        // Get.offAll();

        if (type == 0) {
          Get.offAll(() => MyHomePage());
        } else {
          await uploadImage(widget.fileImage);
          print("UPLOADED");
          Get.offAll(() => MyHomePage());
        }
      },
      child: Container(
        height: size.height * 0.07,
        width: size.width * 0.4,
        child: Stack(
          children: [
            Container(
              decoration: new BoxDecoration(
                  border: Border.all(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(30),
                  gradient: new LinearGradient(
                      colors: [
                        Colors.grey.shade200,
                        Colors.white,
                      ],
                      stops: [
                        0.0,
                        1.0
                      ],
                      begin: FractionalOffset.bottomCenter,
                      end: FractionalOffset.topCenter,
                      tileMode: TileMode.repeated)),
            ),
            Center(
              child: MaterialButton(
                  child: Text(
                    name,
                    style: TextStyle(fontSize: 20, color: AppColor.secondary),
                  ),
                  onPressed: () async {
                    if (type == 0) {
                      Get.offAll(() => MyHomePage());
                    } else {
                      await uploadImage(widget.fileImage);
                      print("UPLOADED");
                      Get.offAll(() => MyHomePage());
                    }
                  }),
            ),
          ],
        ),
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.secondary),
            borderRadius: BorderRadius.circular(30)),
      ),
    );
  }

  uploadImage(File imageFile) async {
    // print(imageFile.path);
    var stream =
        new http.ByteStream(DelegatingStream.typed(imageFile.openRead()));
    var length = await imageFile.length();

    var uri = Uri.parse('https://34d93945af27.ngrok.io/uploadimage/');

    var request = new http.MultipartRequest("POST", uri);
    var multipartFile = new http.MultipartFile('file', stream, length,
        // filename: basename(imageFile.path));
        filename: "images(61).jpeg");
    // contentType: new MediaType('image', 'png'));

    request.files.add(multipartFile);
    setState(() {
      isUploadStart = true;
    });
    var response = await request.send();
    print(response.statusCode);
    String reply = await response.stream.transform(utf8.decoder).join();
    print(reply);
    print(reply.length);
    reply = reply.replaceAll(RegExp('"'), '');
    final decodedBytes = Base64Decoder().convert(reply);
    // final decodedBytes = base64Decode(reply);
    var img = Image.memory(decodedBytes);
    setState(() {
      isUploadStart = false;
      Get.offAll(() => MyHomePage());
      // widget.img = img.image;
      // widget.isResult = true;
    });
    // response.stream.transform(utf8.decoder).listen((value) {
    //   print(value);
    //   print(value.length);
    //   // value = value.replaceAll(RegExp('"'), '');
    //   // final decodedBytes = Base64Decoder().convert(value);

    //   // final decodedBytes = base64Decode(value);

    //   // print(decodedBytes);
    //   // var img = Image.memory(decodedBytes);
    //   // print(img);
    //   setState(() {
    //     // widget.img = img.image;
    //     // widget.isResult = true;
    //   });
    //   //  var file = File("assets/img.jpeg");
    //   // file.writeAsBytesSync(decodedBytes);
    // });
  }
}
