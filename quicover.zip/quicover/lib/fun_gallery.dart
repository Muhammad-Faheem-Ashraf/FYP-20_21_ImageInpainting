import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:quicover/constant.dart';
import 'package:quicover/main.dart';
import 'package:quicover/selection.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
// import 'package:path/path.dart';
import 'package:async/async.dart';

class FunGalleryScreen extends StatefulWidget {
  FunGalleryScreen({Key key}) : super(key: key);

  @override
  _FunGalleryScreenState createState() => _FunGalleryScreenState();
}

class _FunGalleryScreenState extends State<FunGalleryScreen> {
  @override
  void initState() {
    super.initState();

    // var uri = Uri.parse('http://5d74fa8ecab5.ngrok.io/getbucketimage/');
    // print(http.get(uri));
  }

  List _faouriteList = [];
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xFF9BE4FF),
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                gradient: new LinearGradient(
                    colors: [
                  Color(0xFF9BE4FF),
                  Colors.white,
                ],
                    stops: [
                  0.0,
                  1.0
                ],
                    begin: FractionalOffset.bottomCenter,
                    end: FractionalOffset.topCenter,
                    tileMode: TileMode.repeated)),
          ),

          Center(
            child: FutureBuilder(
                future: _fetchListItems(),
                builder: (context, AsyncSnapshot snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  } else {
                    return Container(
                        child: ListView.builder(
                            itemCount: _faouriteList.length,
                            scrollDirection: Axis.vertical,
                            // itemExtent: 0.1,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding: const EdgeInsets.all(20),
                                child: Image(
                                  image: _faouriteList[index],
                                ),
                              );
                            }));
                  }
                }),
          )
          // Center(
          //   child: Container(
          //     child: getButton("BTM", 0),
          //   ),
          // ),
        ],
      ),
    );
  }

  _fetchListItems() async {
    _faouriteList.clear();
    var uri = Uri.parse('https://34d93945af27.ngrok.io/getbucketimage/');
    var response = await http.get(uri);
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      var res = response.body;
      res = res.substring(1, res.length - 1);
      res = res.replaceAll(RegExp('"'), '');
      var list = res.split(",");
      for (int i = 0; i < list.length; i++) {
        var str = list[i];
        str = str.replaceAll(RegExp('"'), '');
        print(str.substring(0, 100));
        final decodedBytes = Base64Decoder().convert(str);
        // final decodedBytes = base64Decode(reply);
        var img = Image.memory(decodedBytes);
        _faouriteList.add(img.image);
      }
      return true;
    }
  }
}
