import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:quicover/show_image.dart';
import 'constant.dart';

class SelectionScreen extends StatefulWidget {
  SelectionScreen({Key key, this.type}) : super(key: key);
  final int type;

  @override
  _SelectionScreenState createState() => _SelectionScreenState();
}

class _SelectionScreenState extends State<SelectionScreen> {
  File _image;
  final picker = ImagePicker();

  Future getImage(ImageSource source) async {
    final pickedFile = await picker.getImage(source: source);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xFF9BE4FF),
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                gradient: new LinearGradient(
                    colors: [
                  Color(0xFF9BE4FF),
                  Colors.white,
                ],
                    stops: [
                  0.0,
                  1.0
                ],
                    begin: FractionalOffset.bottomCenter,
                    end: FractionalOffset.topCenter,
                    tileMode: TileMode.repeated)),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(
                  top: size.height * 0.1, bottom: size.height * 0.1),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Container(
                    height: 100,
                    width: size.width * 0.8,
                    child: Row(
                      children: [
                        Container(
                          height: size.width * 0.2,
                          child: Image(
                            image: AssetImage("assets/App Logo.png"),
                          ),
                        ),
                        Container(
                          height: size.width * 0.2,
                          child: Image(
                            image: AssetImage("assets/Name.png"),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: size.height * 0.4,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        getButton("Camera", 0),
                        getButton("Gallery", 1),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  getButton(String name, int type) {
    var size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () async {
        if (type == 0) {
          await getImage(ImageSource.camera);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      ShowImageScreen(image: _image, type: widget.type)));
        } else if (type == 1) {
          await getImage(ImageSource.gallery);

          print("HEREE IN Selection SCREEEEN IT IS ");
          print(widget.type);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      ShowImageScreen(image: _image, type: widget.type)));
        }
      },
      child: Container(
        height: size.height * 0.1,
        width: size.width * 0.8,
        child: Stack(
          children: [
            Container(
              decoration: new BoxDecoration(
                  border: Border.all(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(30),
                  gradient: new LinearGradient(
                      colors: [
                        Colors.grey.shade200,
                        Colors.white,
                      ],
                      stops: [
                        0.0,
                        1.0
                      ],
                      begin: FractionalOffset.bottomCenter,
                      end: FractionalOffset.topCenter,
                      tileMode: TileMode.repeated)),
            ),
            Center(
              child: MaterialButton(
                  child: Text(
                    name,
                    style: TextStyle(fontSize: 30, color: AppColor.secondary),
                  ),
                  onPressed: () async {
                    if (type == 0) {
                      await getImage(ImageSource.camera);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ShowImageScreen(
                                  image: _image, type: widget.type)));
                    } else if (type == 1) {
                      await getImage(ImageSource.gallery);
                      print("HEREE IN Selection SCREEEEN IT IS ");
                      print(widget.type);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ShowImageScreen(
                                  image: _image, type: widget.type)));
                    }
                  }),
            ),
          ],
        ),
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.secondary),
            borderRadius: BorderRadius.circular(30)),
      ),
    );
  }
}
