import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:path_provider/path_provider.dart';
import 'package:quicover/constant.dart';
import 'package:quicover/selection.dart';
import 'package:http/http.dart' as http;

// import 'package:path/path.dart';
import 'package:async/async.dart';
import 'package:quicover/show_result.dart';

class ShowImageScreen extends StatefulWidget {
  ShowImageScreen({Key key, this.image, this.type}) : super(key: key) {
    img = image;
  }
  final File image;
  final int type;
  var img;
  var isResult = false;
  @override
  _ShowImageScreenState createState() => _ShowImageScreenState();
}

class _ShowImageScreenState extends State<ShowImageScreen> {
  bool isUploadStart = false;

  static final String uploadEndPoint = 'http://35d77bc98271.ngrok.io/images';
  Future<File> file;
  String status = '';
  String base64Image;
  File tmpFile;
  String errMessage = 'Error Uploading Image';

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xFF9BE4FF),
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                gradient: new LinearGradient(
                    colors: [
                  Color(0xFF9BE4FF),
                  Colors.white,
                ],
                    stops: [
                  0.0,
                  1.0
                ],
                    begin: FractionalOffset.bottomCenter,
                    end: FractionalOffset.topCenter,
                    tileMode: TileMode.repeated)),
          ),
          Center(
            child: Container(
              height: size.height * 0.6,
              width: size.width * 0.9,
              child: widget.image == null
                  ? Text('No image selected.')
                  : Image.file(widget.img),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 0),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: getButton("TAKE AGAIN", 0),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 0),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: getButton("UPLOAD", 1),
                  ),
                )
              ],
            ),
          ),
          isUploadStart
              ? Container(
                  color: Colors.black.withOpacity(0.5),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                )
              : Container(),
          isUploadStart
              ? Center(child: CircularProgressIndicator())
              : Container()
        ],
      ),
    );
  }

  getButton(String name, int type) {
    var size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () async {
        if (type == 0) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => SelectionScreen(
                        type: type,
                      )));
        } else {
          await uploadImage(widget.image);
        }
      },
      child: Container(
        height: size.height * 0.07,
        width: size.width * 0.4,
        child: Stack(
          children: [
            Container(
              decoration: new BoxDecoration(
                  border: Border.all(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(30),
                  gradient: new LinearGradient(
                      colors: [
                        Colors.grey.shade200,
                        Colors.white,
                      ],
                      stops: [
                        0.0,
                        1.0
                      ],
                      begin: FractionalOffset.bottomCenter,
                      end: FractionalOffset.topCenter,
                      tileMode: TileMode.repeated)),
            ),
            Center(
              child: MaterialButton(
                  child: Text(
                    name,
                    style: TextStyle(fontSize: 20, color: AppColor.secondary),
                  ),
                  onPressed: () async {
                    // await uploadImage(widget.image);
                    if (type == 0) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SelectionScreen(
                                    type: type,
                                  )));
                    } else {
                      await uploadImage(widget.image);
                    }
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => SelectionScreen(
                    //               type: type,
                    //             )));
                  }),
            ),
          ],
        ),
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.secondary),
            borderRadius: BorderRadius.circular(30)),
      ),
    );
  }

  setStatus(String message) {
    setState(() {
      status = message;
    });
  }

  startUpload() {
    setStatus('Uploading Image...');
    if (null == tmpFile) {
      setStatus(errMessage);
      return;
    }
    String fileName = tmpFile.path.split('/').last;
    upload();
  }

  upload() {
    http.post(Uri.parse(uploadEndPoint), body: {
      "image": widget.image,
    }).then((result) {
      print("RESULTTTTTt");
      print(result.toString());
      //setStatus(result.statusCode == 200 ? result.body : errMessage);
    }).catchError((error) {
      setStatus(error);
    });
  }

  uploadImage(File imageFile) async {
    var stream =
        new http.ByteStream(DelegatingStream.typed(imageFile.openRead()));
    var length = await imageFile.length();

    var uri;
    print("HERE WE ARE GETTINGGGGG ");
    print(widget.type);
    if (widget.type == 0) {
      uri = Uri.parse('https://34d93945af27.ngrok.io/denoiseimage/');
    } else {
      uri = Uri.parse('https://34d93945af27.ngrok.io/sharpimage/');
    }

    var request = new http.MultipartRequest("POST", uri);
    var multipartFile = new http.MultipartFile('file', stream, length,
        // filename: basename(imageFile.path));
        filename: "images(61).jpeg");
    // contentType: new MediaType('image', 'png'));

    request.files.add(multipartFile);
    setState(() {
      isUploadStart = true;
    });
    var response = await request.send();
    print(response.statusCode);
    String reply = await response.stream.transform(utf8.decoder).join();
    print(reply);
    print(reply.length);
    reply = reply.replaceAll(RegExp('"'), '');
    final decodedBytes = Base64Decoder().convert(reply);
    // final decodedBytes = base64Decode(reply);
    var img = Image.memory(decodedBytes);

    final dir = await getExternalStorageDirectory();
    final myImagePath = dir.path + "/myimg.png";
    imageFile = File(myImagePath);
    if (!await imageFile.exists()) {
      imageFile.create(recursive: true);
    }
    imageFile.writeAsBytes(decodedBytes);
    // var f = File('./img.jpeg').writeAsBytes(decodedBytes);
    print("THIS IS IMAGEEEE");
    print(imageFile);
    setState(() {
      isUploadStart = false;
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ShowResultScreen(
                    image: img.image,
                    list: decodedBytes,
                    fileImage: imageFile,
                  )));
      // widget.img = img.image;
      // widget.isResult = true;
    });
    // response.stream.transform(utf8.decoder).listen((value) {
    //   print(value);
    //   print(value.length);
    //   // value = value.replaceAll(RegExp('"'), '');
    //   // final decodedBytes = Base64Decoder().convert(value);

    //   // final decodedBytes = base64Decode(value);

    //   // print(decodedBytes);
    //   // var img = Image.memory(decodedBytes);
    //   // print(img);
    //   setState(() {
    //     // widget.img = img.image;
    //     // widget.isResult = true;
    //   });
    //   //  var file = File("assets/img.jpeg");
    //   // file.writeAsBytesSync(decodedBytes);
    // });
  }
}
