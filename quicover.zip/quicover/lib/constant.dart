import 'dart:ui';

class AppColor {
  static Color primary = Color(0xFF9BE4FF);
  static Color secondary = Color(0xFF787979);
}
